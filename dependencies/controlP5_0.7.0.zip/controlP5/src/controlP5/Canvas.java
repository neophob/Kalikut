package controlP5;


public abstract class Canvas extends ControlWindowCanvas {

	// Wrapper class.

}
