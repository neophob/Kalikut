package controlP5;

public class Group extends ControlGroup<Group> {

	public Group(ControlP5 theControlP5, ControllerGroup<?> theParent, String theName, int theX, int theY, int theW, int theH) {
		super(theControlP5, theParent, theName, theX, theY, theW, theH);
	}

}
